<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Groupe;
use App\Entity\Category;
use App\Form\GroupeType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
class HomeController extends AbstractController
{
    /**
     * @Route("/index", name="index")
     */
    public function index() // Retourne la page d'accueil
    {
        return $this->render('home/index.html.twig');
    }
    /**
     * @Route("/home", name="home")
     */
    public function home() // Page utilisateur
    {
    $groupe = new Groupe();

    $form= $this->createForm(GroupeType::class, $groupe);
        return $this->render('user/home.html.twig', [
          'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/user", name="index")
     */
     public function user() {
       return $this->render('user/groupe_form.html.twig');
     }
}
